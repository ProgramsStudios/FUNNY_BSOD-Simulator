﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUNNY_BSOD
{
    public partial class Payload : Form
    {
        public Payload()
        {
            InitializeComponent();
            TransparencyKey = BackColor;
        }

        private void Payload_Load(object sender, EventArgs e)
        {
            (new BSOD_PANEL()).ShowDialog();
        }
    }
}
