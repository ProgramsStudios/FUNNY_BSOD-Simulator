﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUNNY_BSOD
{
    public partial class BSOD_PANEL : Form
    {
        public BSOD_PANEL()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            (new Win11_BSOD()).ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            (new Win10_BSOD()).ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            (new Win8_BSOD()).ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            (new Win7_BSOD()).ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            (new WinVista_BSOD()).ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            (new WinXP_BSOD()).ShowDialog();
        }

        private void BSOD_PANEL_Load(object sender, EventArgs e)
        {
            
        }
    }
}
